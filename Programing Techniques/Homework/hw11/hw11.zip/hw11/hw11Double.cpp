#include "unsortedDouble.h"
#include <iostream>
#include <string>
#include <functional>

using namespace std;

// write your functions here.
